Author: Stuart Beesley - StuWareSoftSystems (March 2021 - a lockdown project)

Get more Scripts/Extensions from: https://yogi1967.github.io/MoneydancePythonScripts/

Extension format only >> Minimum Moneydance version 2021.1 (build: 3056)
NOTE: You may need to download the MD preview version from: https://infinitekind.com/preview
(If you have installed the extension, but nothing happens, then check your Moneydance version)

This is a Python(Jython 2.7) Extension that runs inside of Moneydance via the Moneybot Python Interpreter
It's a prototype to demonstrate the capabilities of Python. Yes - if you can do it in Java, you can do it in Python too!

DISCLAIMER: THIS EXTENSION IS READONLY - BUT YOU USE AT YOUR OWN RISK!

PURPOSE

This extension creates a Moneydance Home Page View >> a little widget on the Home / Summary Screen dashboard
- It allows you to select multiple accounts, and then the balances are totalled to present on the Home screen widget
- The concept is to add to zero. Thus a positive number is 'good', a negative is 'bad'
- The idea is that you net cash and debt to get back to zero every month
- But you can use it for anything really

- You have the option to change the balance type too

Thanks for reading..... ;->